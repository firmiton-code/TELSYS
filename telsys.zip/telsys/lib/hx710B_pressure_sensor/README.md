# Library for MPS20N0040D with HX710B Pressure Sensor Module

### by: R.Pelayo

### Full tutorial: https://www.teachmemicro.com/arduino-pressure-sensor-tutorial
